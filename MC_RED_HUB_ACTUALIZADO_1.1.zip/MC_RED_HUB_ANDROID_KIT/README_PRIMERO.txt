MC RED HUB — PAQUETE PARA PREPARAR EL APK
========================================

Este ZIP incluye:
1. android-project/: proyecto Android Studio que envuelve la web app.
2. web-source/: copia completa del proyecto web Node.js original.

IMPORTANTE: el APK es una aplicación contenedora (WebView). La web app original
usa un servidor Node.js, una base SQLite, sesiones, Google OAuth y Socket.IO.
Por eso, antes de usar todas las funciones desde Android, debes publicar el
servidor web en una dirección HTTPS pública y colocar esa dirección en:

android-project/app/src/main/assets/app-config.json

Cambia el valor de startUrl por tu dirección, por ejemplo:
{"startUrl":"https://tu-dominio-real.com"}

No escribas literalmente el ejemplo; debes usar el dominio real donde se haya
desplegado server.js. No incluyas secretos de Google dentro de la app.

COMPILAR EL APK
---------------
1. Instala Android Studio en una computadora (Windows, macOS o Linux).
2. En Android Studio instala Android SDK Platform 35 y Build Tools 35.x.
3. Extrae este ZIP.
4. Abre la carpeta android-project en Android Studio.
5. Cambia startUrl en app/src/main/assets/app-config.json por la URL HTTPS
   pública de tu servidor MC RED HUB.
6. Pulsa Sync Project with Gradle Files y acepta la descarga de componentes
   de Gradle/Android que Android Studio solicite.
7. Ve a Build > Build Bundle(s) / APK(s) > Build APK(s).
8. El APK de prueba aparecerá en:
   android-project/app/build/outputs/apk/debug/app-debug.apk

PARA INSTALAR EN ANDROID
------------------------
Copia app-debug.apk al teléfono, ábrelo y autoriza la instalación desde esa
fuente cuando Android lo solicite.

REQUISITOS Y LIMITACIONES
-------------------------
- Este paquete es un proyecto Android listo para abrir/compilar, no es el APK
  ya compilado.
- No contiene Android SDK ni herramientas de compilación; Android Studio las
  descarga e instala.
- La app Android carga la web alojada en startUrl. No ejecuta Node.js dentro
  del teléfono. Sin servidor publicado, el catálogo, publicaciones, sesiones
  y chat en línea no estarán disponibles.
- Las copias de mundos y el editor local funcionan dentro del almacenamiento
  web de la app; la persistencia depende de los datos de la aplicación.
- Google no permite OAuth dentro del WebView. Esta versión abre el flujo de
  inicio en el navegador externo y vuelve con un enlace mcredhub://auth y un
  código de un solo uso que el servidor canjea por una sesión del WebView.
  Debes configurar OAuth en Google Cloud antes de usarlo.
- Los enlaces externos (por ejemplo páginas de descarga) se abren en el
  navegador. Las descargas servidas desde la web se procesan con Download
  Manager de Android.
- Para generar un APK de publicación, configura una firma propia desde
  Build > Generate Signed Bundle / APK.

IDENTIFICADOR ANDROID
---------------------
Nombre: MC RED HUB
Application ID: com.mcredhub.app
Versión inicial: 1.0 (versionCode 1)

El proyecto usa Android Gradle Plugin 8.7.3 y requiere JDK 17 o superior.


ACTUALIZACIÓN DE LA VERSIÓN
--------------------------
La carpeta web-source ahora incluye Skin 3D Lab, publicación pública de mods con alias opcional, escaneo ClamAV obligatorio por defecto y almacenamiento configurable con STORAGE_ROOT. Antes de habilitar subidas, instala ClamAV. Antes de uso público, configura Google OAuth y un volumen persistente. Consulta web-source/README.md y web-source/DEPLOYMENT.txt.

El ZIP Skin Editor 3D_src enviado para referencia es una extracción de una app Android Unity compilada (APK/IL2CPP), no un proyecto Unity fuente. Por eso el editor web incluido es una implementación integrada para MC RED HUB basada en textura Bedrock, no una conversión literal de ese binario ni una garantía de que reproduzca funciones internas no documentadas del APK.
