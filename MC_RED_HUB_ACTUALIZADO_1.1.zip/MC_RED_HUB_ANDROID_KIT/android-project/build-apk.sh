#!/usr/bin/env bash
set -euo pipefail
VERSION=8.9
ROOT="${HOME}/.local/share/mc-red-hub"
GRADLE_HOME_LOCAL="${ROOT}/gradle-${VERSION}"
if [[ ! -x "${GRADLE_HOME_LOCAL}/bin/gradle" ]]; then
  mkdir -p "${ROOT}"
  ZIP="${ROOT}/gradle-${VERSION}-bin.zip"
  echo "Descargando Gradle ${VERSION}..."
  curl -fL "https://services.gradle.org/distributions/gradle-${VERSION}-bin.zip" -o "${ZIP}"
  unzip -oq "${ZIP}" -d "${ROOT}"
  rm -f "${ZIP}"
fi
cd "$(dirname "$0")"
"${GRADLE_HOME_LOCAL}/bin/gradle" assembleDebug
printf '\nAPK creado en: app/build/outputs/apk/debug/app-debug.apk\n'
