package com.mcredhub.app;

import android.app.Activity;
import android.app.DownloadManager;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.ProgressBar;
import android.widget.Toast;
import android.util.Base64;
import java.io.OutputStream;

import org.json.JSONObject;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private static final int FILE_CHOOSER_REQUEST = 501;
    private static final int CREATE_FILE_REQUEST = 502;
    private WebView webView;
    private ProgressBar progressBar;
    private ValueCallback<Uri[]> fileCallback;
    private String startUrl;
    private byte[] pendingSaveBytes;
    private String pendingSaveName;
    private String pendingSaveMime;
    private String pendingGoogleTicket;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(0xFF101014);
        getWindow().setNavigationBarColor(0xFF101014);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED);

        startUrl = readStartUrl();
        FrameLayout root = new FrameLayout(this);
        webView = new WebView(this);
        progressBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progressBar.setMax(100);
        progressBar.setProgressTintList(android.content.res.ColorStateList.valueOf(0xFFE53945));
        progressBar.setBackgroundColor(0xFF26232A);
        FrameLayout.LayoutParams webParams = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT);
        FrameLayout.LayoutParams progressParams = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, dp(3));
        root.addView(webView, webParams);
        root.addView(progressBar, progressParams);
        setContentView(root);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setLoadsImagesAutomatically(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setSupportMultipleWindows(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);

        webView.addJavascriptInterface(new WebAppBridge(), "MCREDHUB");

        webView.setWebChromeClient(new WebChromeClient() {
            @Override public void onProgressChanged(WebView view, int newProgress) {
                progressBar.setProgress(newProgress);
                progressBar.setVisibility(newProgress >= 100 ? View.GONE : View.VISIBLE);
            }

            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                                             FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{
                        "image/png", "image/jpeg", "application/zip", "application/octet-stream", "*/*"});
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                try {
                    startActivityForResult(intent, FILE_CHOOSER_REQUEST);
                } catch (ActivityNotFoundException ex) {
                    fileCallback = null;
                    Toast.makeText(MainActivity.this, "No se encontró un selector de archivos.", Toast.LENGTH_LONG).show();
                    return false;
                }
                return true;
            }
        });

        webView.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                // Permite exportar archivos Blob creados por la web app (por ejemplo,
                // una copia .mcworld generada desde IndexedDB) mediante el selector Android.
                String script = "(function(){if(window.__mcrhBlobBridge)return;window.__mcrhBlobBridge=true;" +
                        "document.addEventListener('click',function(ev){var a=ev.target.closest('a[download]');" +
                        "if(!a||!a.href||!a.href.startsWith('blob:'))return;ev.preventDefault();" +
                        "fetch(a.href).then(function(r){return r.blob()}).then(function(b){var fr=new FileReader();" +
                        "fr.onloadend=function(){if(window.MCREDHUB&&window.MCREDHUB.saveBase64File)" +
                        "window.MCREDHUB.saveBase64File(fr.result,a.download||'mc-red-hub-file')};" +
                        "fr.readAsDataURL(b)}).catch(function(){alert('No se pudo preparar el archivo para guardar')});" +
                        "},true)})()";
                view.evaluateJavascript(script, null);
                deliverPendingGoogleTicket();
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if (isSameHost(uri) && "/auth/google".equals(uri.getPath())
                        && "android".equals(uri.getQueryParameter("client"))) {
                    // Google no permite OAuth dentro de Android WebView: se abre el navegador del sistema.
                    openExternal(uri);
                    return true;
                }
                if (isSameHost(uri)) return false;
                openExternal(uri);
                return true;
            }

            @Override public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame()) {
                    Toast.makeText(MainActivity.this,
                            "No se pudo abrir MC RED HUB. Comprueba la conexión y la URL del servidor.",
                            Toast.LENGTH_LONG).show();
                }
            }
        });

        webView.setDownloadListener((url, userAgent, contentDisposition, mimeType, contentLength) -> {
            try {
                Uri uri = Uri.parse(url);
                if (!"https".equalsIgnoreCase(uri.getScheme())) {
                    openExternal(uri);
                    return;
                }
                DownloadManager.Request request = new DownloadManager.Request(uri);
                String fileName = URLUtil.guessFileName(url, contentDisposition, mimeType);
                request.setTitle(fileName);
                request.setDescription("Descargando desde MC RED HUB");
                request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName);
                String cookie = CookieManager.getInstance().getCookie(url);
                if (cookie != null) request.addRequestHeader("Cookie", cookie);
                if (userAgent != null) request.addRequestHeader("User-Agent", userAgent);
                DownloadManager manager = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
                manager.enqueue(request);
                Toast.makeText(this, "Descarga iniciada: " + fileName, Toast.LENGTH_SHORT).show();
            } catch (Exception ex) {
                Toast.makeText(this, "No se pudo iniciar la descarga.", Toast.LENGTH_LONG).show();
            }
        });

        if (isConfigured(startUrl)) webView.loadUrl(startUrl);
        else webView.loadUrl("file:///android_asset/setup.html");
        handleGoogleDeepLink(getIntent());
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleGoogleDeepLink(intent);
    }

    private void handleGoogleDeepLink(Intent intent) {
        if (intent == null || intent.getData() == null) return;
        Uri data = intent.getData();
        if ("mcredhub".equalsIgnoreCase(data.getScheme()) && "auth".equalsIgnoreCase(data.getHost())) {
            pendingGoogleTicket = data.getQueryParameter("ticket");
            deliverPendingGoogleTicket();
        }
    }

    private void deliverPendingGoogleTicket() {
        if (pendingGoogleTicket == null || webView == null || webView.getProgress() < 100) return;
        String ticket = pendingGoogleTicket;
        pendingGoogleTicket = null;
        String script = "window.completeNativeGoogleLogin && window.completeNativeGoogleLogin(" + JSONObject.quote(ticket) + ");";
        webView.post(() -> webView.evaluateJavascript(script, null));
    }

    private class WebAppBridge {
        @JavascriptInterface
        public void saveBase64File(String dataUrl, String fileName) {
            try {
                int comma = dataUrl.indexOf(',');
                if (comma < 0) throw new IllegalArgumentException("Datos de archivo no válidos");
                byte[] decoded = Base64.decode(dataUrl.substring(comma + 1), Base64.DEFAULT);
                if (decoded.length > 100 * 1024 * 1024) {
                    runOnUiThread(() -> Toast.makeText(MainActivity.this,
                            "El archivo supera el límite de 100 MB.", Toast.LENGTH_LONG).show());
                    return;
                }
                String safeName = (fileName == null || fileName.trim().isEmpty()) ? "mc-red-hub-file" : fileName;
                String lower = safeName.toLowerCase();
                String mime = lower.endsWith(".png") ? "image/png" :
                        (lower.endsWith(".zip") || lower.endsWith(".mcworld") ? "application/zip" :
                        (lower.endsWith(".mcpack") || lower.endsWith(".mcaddon") ? "application/octet-stream" : "application/octet-stream"));
                runOnUiThread(() -> {
                    pendingSaveBytes = decoded;
                    pendingSaveName = safeName;
                    pendingSaveMime = mime;
                    Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType(mime);
                    intent.putExtra(Intent.EXTRA_TITLE, safeName);
                    try {
                        startActivityForResult(intent, CREATE_FILE_REQUEST);
                    } catch (ActivityNotFoundException ex) {
                        pendingSaveBytes = null;
                        Toast.makeText(MainActivity.this, "No se encontró una aplicación para guardar archivos.", Toast.LENGTH_LONG).show();
                    }
                });
            } catch (Exception ex) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this,
                        "No se pudo preparar el archivo descargado.", Toast.LENGTH_LONG).show());
            }
        }
    }

    private String readStartUrl() {
        try (InputStream stream = getAssets().open("app-config.json")) {
            byte[] data = new byte[stream.available()];
            int count = stream.read(data);
            JSONObject config = new JSONObject(new String(data, 0, Math.max(0, count), StandardCharsets.UTF_8));
            return config.optString("startUrl", "").trim();
        } catch (Exception ignored) {
            return "";
        }
    }

    private boolean isConfigured(String url) {
        if (url == null || url.isEmpty() || url.contains("CAMBIA-ESTA-URL")) return false;
        Uri uri = Uri.parse(url);
        return "https".equalsIgnoreCase(uri.getScheme()) && uri.getHost() != null;
    }

    private boolean isSameHost(Uri uri) {
        Uri base = Uri.parse(startUrl);
        return uri.getHost() != null && base.getHost() != null
                && uri.getHost().equalsIgnoreCase(base.getHost())
                && ("https".equalsIgnoreCase(uri.getScheme()));
    }

    private void openExternal(Uri uri) {
        String scheme = uri.getScheme();
        if (!"https".equalsIgnoreCase(scheme) && !"http".equalsIgnoreCase(scheme)) return;
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, uri));
        } catch (ActivityNotFoundException ignored) {
            Toast.makeText(this, "No hay una aplicación para abrir este enlace.", Toast.LENGTH_SHORT).show();
        }
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    @SuppressWarnings("deprecation")
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER_REQUEST && fileCallback != null) {
            Uri[] results = null;
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                results = new Uri[]{data.getData()};
            }
            fileCallback.onReceiveValue(results);
            fileCallback = null;
        } else if (requestCode == CREATE_FILE_REQUEST) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null && pendingSaveBytes != null) {
                try (OutputStream output = getContentResolver().openOutputStream(data.getData())) {
                    if (output == null) throw new IllegalStateException("No se pudo abrir el archivo de destino");
                    output.write(pendingSaveBytes);
                    Toast.makeText(this, "Archivo guardado correctamente.", Toast.LENGTH_LONG).show();
                } catch (Exception ex) {
                    Toast.makeText(this, "No se pudo guardar el archivo.", Toast.LENGTH_LONG).show();
                }
            }
            pendingSaveBytes = null;
            pendingSaveName = null;
            pendingSaveMime = null;
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (fileCallback != null) fileCallback.onReceiveValue(null);
        if (webView != null) {
            webView.stopLoading();
            webView.destroy();
        }
        super.onDestroy();
    }
}
