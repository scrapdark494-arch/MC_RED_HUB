@echo off
setlocal
set "GRADLE_VERSION=8.9"
set "GRADLE_HOME_LOCAL=%LOCALAPPDATA%\MCREDHUB\gradle-%GRADLE_VERSION%"
if not exist "%GRADLE_HOME_LOCAL%\bin\gradle.bat" (
  echo Descargando Gradle %GRADLE_VERSION%...
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; $ProgressPreference='SilentlyContinue'; $root=Join-Path $env:LOCALAPPDATA 'MCREDHUB'; New-Item -ItemType Directory -Force -Path $root ^| Out-Null; $zip=Join-Path $env:TEMP 'gradle-8.9-bin.zip'; Invoke-WebRequest -Uri 'https://services.gradle.org/distributions/gradle-8.9-bin.zip' -OutFile $zip; Expand-Archive -Path $zip -DestinationPath $root -Force; Remove-Item $zip -Force"
  if errorlevel 1 (echo No se pudo descargar Gradle. Comprueba tu conexion. & exit /b 1)
)
cd /d "%~dp0"
call "%GRADLE_HOME_LOCAL%\bin\gradle.bat" assembleDebug
if errorlevel 1 exit /b 1
echo.
echo APK creado en: app\build\outputs\apk\debug\app-debug.apk
endlocal
