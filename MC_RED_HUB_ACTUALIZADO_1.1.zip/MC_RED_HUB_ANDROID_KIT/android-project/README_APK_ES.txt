COMO GENERAR MC RED HUB EN APK (ANDROID)
========================================

ANTES DE COMPILAR
-----------------
A) Debes publicar el backend Node.js que está en la carpeta ../web-source.
   El backend necesita Node.js 20+, almacenamiento persistente para data/ y
   uploads/, HTTPS y las variables OAuth descritas en web-source/README.md.
B) Cuando tengas una URL HTTPS pública (por ejemplo https://mi-dominio.com),
   edita este archivo:
   app/src/main/assets/app-config.json
   y coloca esa URL en startUrl.
C) No agregues GOOGLE_CLIENT_SECRET ni SESSION_SECRET en la app Android. Esos
   secretos van únicamente en las variables privadas del servidor.

COMPILAR CON WINDOWS
--------------------
1. Instala Android Studio y abre el SDK Manager.
2. Instala Android SDK Platform 35 y Android SDK Build-Tools 35.x.
3. Extrae el paquete completo.
4. En Android Studio abre la carpeta android-project.
5. Si Android Studio solicita JDK, usa el JDK 17 integrado.
6. Abre la pestaña Terminal dentro de Android Studio y ejecuta:
      build-apk.bat
   El script descarga Gradle 8.9 si aún no está instalado y compila el APK.
7. Archivo resultante:
      app\build\outputs\apk\debug\app-debug.apk

COMPILAR CON macOS / LINUX
-------------------------
Instala Android Studio + Android SDK Platform 35 y ejecuta en la terminal,
dentro de android-project:
      ./build-apk.sh

Si Gradle no encuentra Android SDK, abre el proyecto una vez en Android Studio,
configura Android SDK Location en SDK Manager y vuelve a ejecutar el script.

PROBAR EN EL TELÉFONO
---------------------
Copia app-debug.apk a tu Android, ábrelo y permite la instalación desde esa
fuente. El archivo debug es para pruebas. Para distribuir una versión pública,
genera una firma propia en Android Studio (Build > Generate Signed Bundle / APK).

QUÉ HACE ESTA VERSIÓN ANDROID
-----------------------------
- Muestra el sitio MC RED HUB publicado bajo tu URL HTTPS.
- Mantiene el contenido web y sus interacciones dentro de la app.
- Abre enlaces de otros sitios en el navegador del teléfono.
- Permite seleccionar archivos para los formularios de subida.
- Descarga archivos HTTPS mediante el gestor de descargas Android.
- Permite guardar descargas Blob generadas por el editor/gestor web mediante
  el selector de archivos Android.

LIMITACIONES QUE DEBES CONOCER
-----------------------------
- No es un servidor Node.js dentro del APK. El backend debe estar publicado.
- Google no permite realizar OAuth dentro de un WebView embebido. Esta versión
  abre el inicio en el navegador externo y vuelve mediante el deep link
  mcredhub://auth; el backend intercambia un código de un solo uso por una sesión
  propia del WebView. No se debe poner el secreto OAuth en la app.
- Este paquete no está firmado para distribución y no contiene un APK final.
- La compilación requiere conexión a Internet para descargar Gradle, Android
  Gradle Plugin y componentes del SDK si todavía no están instalados.


INICIO DE SESIÓN GOOGLE EN ANDROID
---------------------------------
La aplicación abre el flujo OAuth en el navegador externo del teléfono y vuelve a MC RED HUB mediante el enlace mcredhub://auth. Esto evita ejecutar el inicio de sesión de Google dentro del WebView. Configura primero BASE_URL, GOOGLE_CLIENT_ID, GOOGLE_CLIENT_SECRET y SESSION_SECRET en el servidor, además del callback HTTPS registrado en Google Cloud Console.

El APK no debe contener GOOGLE_CLIENT_SECRET. Solo contiene el dominio de la web en app-config.json.
